﻿namespace WEBAPP1.Models
{
    public class Settings
    {
        public string PageSize { get;set; }
        public string? ApiKey { get; set; }
    }
}
