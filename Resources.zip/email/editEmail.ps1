$labVariables = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Virtual Machine\External"
$labInstanceID = $labVariables.'@lab.LabInstance.Id'

$hashTable = @{
	'User-@labinstanceid' = $labVariables.'@lab.CloudPortalCredential(1).Username'
	'TAP-@labinstanceid' = $labVariables.'@lab.CloudPortalCredential(1).AccessToken'
    'password-@labinstanceid' = $labVariables.'@lab.CloudPortalCredential(1).Password'
    '@labInstanceId' = $labVariables.'@lab.LabInstance.Id'
}

if (Test-Path C:\email\email.html) {
    foreach ($key in $hashTable.GetEnumerator()){
        $content = Get-Content C:\email\email.html
        $content.Replace($key.Name, $key.Value) | Set-Content C:\email\email.html
    }
}